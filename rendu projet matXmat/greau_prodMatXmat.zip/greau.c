#define _GNU_SOURCE
#include <stdio.h>
#include <mpi.h>
#include <stdlib.h>
#include <string.h>

struct matrix * allocateMatrix(int nblin, int nbCol);
void printMatrix(struct matrix * s);
void transposeMatrix(struct matrix * s);
void rotateMatrix(struct matrix * s);
void resetMatrix(struct matrix * s);
void produitMat(struct matrix * A,struct matrix * B,struct matrix * C);
int nfinder(char* file);
struct matrix * input(char * file, int n);
void transferInto(struct matrix* source, struct matrix * dest, int tour, int rank,int n);

// COMPILE : mpicc matXmat.c -o mXm
// RUN : mpirun --oversubscribe -np N mXm  // N must be multiple of numprocs

struct matrix {
  // lineariser
 	long * mat;
  int nbColonnes;
  int nbLignes;
};

int main(int argc, char* argv[]){
	int numprocs, rank;
	MPI_Init(&argc, &argv);
	MPI_Comm_size(MPI_COMM_WORLD, &numprocs);
	MPI_Comm_rank(MPI_COMM_WORLD, &rank);
	MPI_Status status;
	int master = 0;

  int * chunkSize = malloc (sizeof(int) * 1); // taille du morceau de matrice
	int * n = malloc (sizeof(int) * 1);
  struct matrix * sourceA = malloc (sizeof(struct matrix));
	struct matrix * sourceB = malloc (sizeof(struct matrix));
	struct matrix * finalC  = malloc (sizeof(struct matrix));

	// donner master toute les donnees
	if (rank == master){
		*n = nfinder(argv[1]);
		sourceA = input (argv[1],*n);
    finalC = allocateMatrix(sourceA->nbLignes,sourceA->nbColonnes);
		sourceB = input (argv[2],*n);
		transposeMatrix(sourceB); //  afin d'avoir les colonnes en lignes : easy scatter
	}

	MPI_Bcast(n,1,MPI_INT,master,MPI_COMM_WORLD);

	// construit les matrix locales de la bonne taille
  struct matrix * localA = malloc (sizeof(struct matrix));
	struct matrix * localB = malloc (sizeof(struct matrix));
	struct matrix * localC = malloc (sizeof(struct matrix));
	struct matrix * localTemp = malloc (sizeof(struct matrix));
	*chunkSize = *n / numprocs;
	localA = allocateMatrix (*chunkSize, *n);
	localB = allocateMatrix (*chunkSize, *n); // car transposee
	localTemp = allocateMatrix(*chunkSize,*chunkSize);
	int * localBtemp = malloc(sizeof (long) * localB->nbColonnes * localB->nbLignes);

	// distribution du travail
  MPI_Scatter(sourceA->mat,*chunkSize * *n,MPI_LONG,localA->mat,*chunkSize * *n,MPI_LONG,master,MPI_COMM_WORLD);
	MPI_Scatter(sourceB->mat, *chunkSize * *n,MPI_LONG,localB->mat, *chunkSize * *n, MPI_LONG,master,MPI_COMM_WORLD);

  if (rank == master){
    free(sourceA->mat);
    free(sourceB->mat);
  }
	// DEBUT travail individuel
	rotateMatrix(localB);
	localC = allocateMatrix(localA->nbLignes,*n);
	int  Successeur =  (rank - 1 + numprocs) % numprocs; // faux pour debug circulation
	int  Predecesseur= (rank + 1) % numprocs;
	for (int tour = 0; tour < numprocs ;tour++){
		// do job
		resetMatrix(localTemp);
		produitMat(localA, localB ,localTemp);
		transferInto(localTemp,localC,tour,rank,*n);
		// end job

		// transmit chunk of B
		if ( numprocs > 1){
			if (rank != master){
				MPI_Send (localB->mat, localB->nbLignes * localB->nbColonnes, MPI_LONG, Successeur, tour , MPI_COMM_WORLD);
				MPI_Recv (localB->mat, localB->nbLignes * localB->nbColonnes, MPI_LONG, Predecesseur, tour , MPI_COMM_WORLD, &status);
			}
			else {
				memcpy(localBtemp,localB->mat,sizeof (long) * localB->nbColonnes * localB->nbLignes);

				MPI_Recv (localB->mat, localB->nbLignes * localB->nbColonnes, MPI_LONG, Predecesseur, tour , MPI_COMM_WORLD, &status);
				MPI_Send (localBtemp, localB->nbLignes * localB->nbColonnes, MPI_LONG, Successeur, tour , MPI_COMM_WORLD);
			}
		}
	}

  // once all finished, gather at master
		MPI_Gather (localC->mat,localC->nbLignes *localC->nbColonnes ,MPI_LONG, finalC->mat,localC->nbLignes *localC->nbColonnes,MPI_LONG,master,MPI_COMM_WORLD);


	if (rank == master ){
		printMatrix(finalC);
  }

	MPI_Finalize();
}





//__________________functions____________________

void produitMat(struct matrix * A,struct matrix * B,struct matrix * C){
	int n = A->nbColonnes;
	#pragma omp parallel for
  for (int i = 0; i < A->nbLignes; i ++){ // ligne
    for (int j = 0; j < B->nbColonnes; j++){ // colonne
      for (int k = 0 ; k < n; k++){
        // C[i,j] = C[i,j] + A[i,k] * B [k,j]
				C->mat[i*C->nbColonnes + j] = C->mat[i*C->nbColonnes + j] +	A->mat[i*A->nbColonnes + k] * B->mat[k*B->nbColonnes + j];
      }
    }
  }
}

struct matrix * allocateMatrix(int nblin, int nbCol) {
  struct matrix * tmp = malloc(sizeof(struct matrix));
  tmp->nbColonnes = nbCol;
  tmp->nbLignes = nblin;
  tmp->mat = calloc(nblin * nbCol, sizeof(long));
  return tmp;
}

void transposeMatrix(struct matrix * s){
	// pour recuperer les colonnes
  struct matrix * rotated = allocateMatrix(s->nbColonnes,s->nbLignes);
	#pragma omp parallel for
  for (int l = 0; l < s->nbLignes; l++){
    for (int c = 0; c < s->nbColonnes; c++){
      rotated->mat[ l * s->nbColonnes + c] = s->mat[ c * s->nbLignes + l];
    }
  }
	int n;
	n = s->nbColonnes;
	s->nbColonnes = s->nbLignes;
	s->nbLignes = n;
	free(s->mat);
	*s = *rotated;
}

void rotateMatrix(struct matrix * s){
	struct matrix * rotated = allocateMatrix(s->nbColonnes,s->nbLignes);
	#pragma omp parallel for
	for (int i = 0; i < s->nbLignes; i++){
		for (int j = 0; j < s->nbColonnes; j ++){
			// A [i,j] => A [j,i]
			rotated->mat[j*s->nbLignes + i] = s->mat[i * s->nbColonnes + j];
		}
	}
	int n;
	n = s->nbColonnes;
	s->nbColonnes = s->nbLignes;
	s->nbLignes = n;
	free(s->mat);
	*s = *rotated;
}

void printMatrix(struct matrix * s){
  //printf("---- Matrix of %i lanes & %i columns---- \n", s->nbLignes,s->nbColonnes);
  for (int i = 0; i < s->nbLignes; i++){
    for (int j = 0; j < s->nbColonnes; j++){
      printf("%ld ", s->mat[i*s->nbColonnes + j]);
    }
    printf ("\n");
  }
}

int nfinder(char* file){
	FILE* fichier = NULL;
	fichier = fopen(file, "r");
	if(fichier == NULL){
		fprintf(stderr, "The file \"%s\" doesn't exist.\n", file);
		exit(EXIT_FAILURE);
	}else { // procedure normale
		char * line = NULL;
		char * token;
		size_t len = 0;
		int n = 0;

		getline(&line, &len, fichier);

		token = strtok(line, " ");

	  while(token != NULL){
			  token = strtok(NULL, " ");
	      n++;
	  }
		return n;
	}
}

struct matrix * input(char * file, int n){
	struct matrix *source = malloc (sizeof(struct matrix));
	source = allocateMatrix(n,n);
	char * line = NULL;
	size_t len = 0;
	FILE* fichier = NULL;
	fichier = fopen(file, "r");
	if(fichier == NULL){
		fprintf(stderr, "The file \"%s\" doesn't exist.\n", file);
		exit(EXIT_FAILURE);
	}

	char * token;

	for (int i = 0; i < n; i++){
		getline(&line,&len, fichier);
		token = strtok(line, " ");

		for (int j = 0; j < n; j++){
			// tokeniser et passer au suivant
			int value = atoi(token);
			source->mat[i*n+j] = value;
			token = strtok(NULL, " ");
		}
	}
	fclose(fichier);
	return source;
}

void transferInto(struct matrix* source, struct matrix * dest, int tour, int rank,int n){
	int offset = ((tour +rank)*source->nbColonnes)%n;
	#pragma omp parallel for
	for (int i =0; i < source->nbLignes; i ++){
		for (int j = 0 ; j < source->nbColonnes; j ++ ){
			dest->mat[offset + j + i*dest->nbColonnes] = source->mat[j + i *source->nbColonnes];
		}
	}
}

void resetMatrix(struct matrix * s){
	#pragma omp parallel for
	for (int i = 0; i < s->nbLignes; i++){
		for (int j = 0; j < s->nbColonnes; j++){
			s->mat[i*s->nbColonnes + j]  = 0;
		}
	}
}
